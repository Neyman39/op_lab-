﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace _2_лаба
{
    class Program
    {
        static void Main(string[] args)
        {
            OneStr ostr = new OneStr("davageva");
            OneStr ostr1 = new OneStr("gevadava");
            OneInt oint = new OneInt(123);
            Two two = new Two();
            Three unint = new Three(321);
            Three unint1 = new Three(647);

            List<object> origin = new List<object>(){oint, ostr, unint1};
            List<object> list1 = new List<object>(){oint};
            List<object> list2 = new List<object>(){oint, two, ostr};
            List<object> list3 = new List<object>(){oint, oint, unint1};
            List<object> list4 = new List<object>(){oint, ostr1, unint1};
            List<object> list5 = new List<object>(){oint, ostr, unint};
            
            ListObjects founder = new ListObjects(origin);
            Console.WriteLine("Тест 1");
            Console.WriteLine($"{founder.Proverka(list1)}\n");
            Console.WriteLine("Тест 2");
            Console.WriteLine($"{founder.Proverka(list2)}\n");
            Console.WriteLine("Тест 3");
            Console.WriteLine($"{founder.Proverka(list3)}\n");
            Console.WriteLine("Тест 4");
            Console.WriteLine($"{founder.Proverka(list4)}\n");
            Console.WriteLine("Тест 5");
            Console.WriteLine($"{founder.Proverka(list5)}\n");

        }
    }

    public class ListObjects
    {
        public List<object> nlist;

        public ListObjects(List<object> asd)
        {
            nlist = asd;
        }

        public string Proverka(List<object> control)
        {
            
            if (control.Count != nlist.Count)
            {
                return "Списки не равны";
            }

            for (int i = 0; i < nlist.Count; i++)
            {
                Type originType = nlist[i].GetType();
                Type controlType = control[i].GetType();

                foreach (Attribute attr in controlType.GetCustomAttributes(false))
                {
                    if (attr is NotComparable)
                    {
                        return $"Найден нечитаемый тип {controlType.Name}! \nВ позиции: {i}";
                    }
                }

                if (originType != controlType)
                {
                    return $"Найдено расхожение в типах в позиции {i}\nПолучено: {controlType}\nОжидалось: {originType}";
                }
                foreach (PropertyInfo prop in originType.GetProperties(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static))
                {
                    var valueOrOb = prop.GetValue(nlist[i]);
                    var valueOb = prop.GetValue(control[i]);
                    foreach (Attribute atr in controlType.GetCustomAttributes(false))
                    { 
                        if (atr is UnreadableAttribute)
                        {
                            return "Коллекции равны";
                        }
                    }
                    if (valueOrOb.Equals(valueOb) == false)
                    {
                        return $"Найдено расхождение в значениях.\nВ позиции: {i} В поле: {prop.Name}\nПолучено: {valueOb}\nОжидалось: {valueOrOb}";
                    }
                }
            }
            return "Коллекции равны";
        }
    }

    public class NotComparable : Attribute
    {
    }
    public class UnreadableAttribute : Attribute
    {
    }

    class OneStr
    {
        public string Name { get; set; }
        public OneStr(string name)
        {
            Name = name;
        }
    }

    class OneInt
    {
        public int Norm {get; set;}
        public OneInt(int norm)
        {
            Norm = norm;
        }
    }

    [NotComparable]
    class Two
    {
        private int notcom { get; set; }
    }

    [Unreadable]
    class Three
    {
        public int Unread {get; set;}
        public Three(int unread)
        {
            Unread = unread;
        }
    }
}
