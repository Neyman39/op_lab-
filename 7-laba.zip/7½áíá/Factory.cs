﻿using System.Collections.Generic;

namespace _6лаба
{
    class Factory
    {
        public List<Department> Departments = new List<Department>();

        public List<Person> Candidates = new List<Person>();
    }
}
