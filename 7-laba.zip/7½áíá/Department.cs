﻿using System.Collections.Generic;

namespace _6лаба
{
    class Department
    {
        public List<Person> Employees = new List<Person>();
        public string Title { get; set; }
        public int NumberOfVacancies { get; set; }
        public virtual void StaffSelectoin(List<Person> candidates)
        {
            foreach (Person x in candidates)
            {
                if (x.score > 3.0)
                    Employees.Add(x);                
            }
            foreach (Person y in Employees)
            {
                candidates.Remove(y);
            }
        }
        public string PrintEmployees()
        {
            string result = "==Список сотрудников департамента " + Title + "==\n";
            foreach (var item in Employees)
            {
                result += item.name + "\n";
            }
            result += "----------";
            return result;
        }
    }

    class Electrician : Department
    {
        public override void StaffSelectoin(List<Person> candidates)
        {
            foreach (Person x in candidates)
            {
                if (x.PersonSpeciality == Person.Specialty.Electrician & x.score >= 4.5 && NumberOfVacancies > 0)
                {
                    Employees.Add(x);
                    NumberOfVacancies--;
                }
            }
            foreach (Person y in Employees)
            {
                candidates.Remove(y);
            }
        }
        public new string PrintEmployees()
        {
            string result = "==Список сотрудников департамента " + Title + "==\n";
            foreach (var item in Employees)
            {
                result += item.name + " " + item.score + "\n";
            }
            result += "----------";
            return result;
        }
    }
    class Mechanic : Department
    {
        public override void StaffSelectoin(List<Person> candidates)
        {
            foreach (Person x in candidates)
            {
                if (x.PersonSpeciality == Person.Specialty.Mechanic & x.score >= 4.0 & x.age <= 35 && NumberOfVacancies > 0)
                {
                    Employees.Add(x);
                    NumberOfVacancies--;
                }
            }
            foreach (Person y in Employees)
            {
                candidates.Remove(y);
            }
        }
        public new string PrintEmployees()
        {
            string result = "==Список сотрудников департамента " + Title + "==\n";
            foreach (var item in Employees)
            {
                result += item.name + " " + item.age + "\n";
            }
            result += "----------";
            return result;
        }
    }
    class Inform : Department
    {
        public override void StaffSelectoin(List<Person> candidates)
        {
            foreach (Person x in candidates)
            {
                if ((x.PersonSpeciality == Person.Specialty.Mathematician | x.PersonSpeciality == Person.Specialty.Programmer) & x.score >= 4.8 & x.age >= 22 && NumberOfVacancies > 0)
                {
                    Employees.Add(x);
                    NumberOfVacancies--;
                }
            }
            foreach (Person y in Employees)
            {
                candidates.Remove(y);
            }
        }
        public new string PrintEmployees()
        {
            string result = "==Список сотрудников департамента " + Title + "==\n";
            foreach (var item in Employees)
            {
                result += item.name + " " + item.PersonSpeciality + " " + item.age + "\n";
            }
            result += "----------";
            return result;
        }
    }
}
