﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asd
{
    class Program
    {
        static void Calc(int[] coll_nums)

        {

            int length = coll_nums.Length;
            Console.WriteLine($"Length of your array: {length}");

            int max = coll_nums.Max();
            Console.WriteLine($"Maximal number in your array: {max}");

            int min = coll_nums.Min();
            Console.WriteLine($"Minimal number in your array: {min}");

            Console.WriteLine(Mult(max, min));

        }

        static int Mult(int max, int min)

        {

            return max * min;

        }
        static void Main(string[] args)
        {
            Console.Write("Enter length of your array: ");
            int array_length = Convert.ToInt32(Console.ReadLine());

            Console.Clear();

            int[] coll_nums = new int[array_length];

            for (int i = 0; i < coll_nums.Length; i++)

            {

                Console.Write($"Enter a number under index ({i}): ");
                coll_nums[i] = Convert.ToInt32(Console.ReadLine());
                Console.Clear();

            }

            Calc(coll_nums);
            //Console.WriteLine($"Result of multiplication: {prod}");





        }
    }
}
