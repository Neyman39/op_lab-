﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6лаба
{
    class Program
    {
        static void Main(string[] args)
        {
            Person pers1 = new Person()
            {
                name = "Андрей",
                age = 24,
                PersonSpeciality = Person.Specialty.Programmer,
                score = 4.8,
            };
            Person pers2 = new Person()
            {
                name = "Никита",
                age = 52,
                PersonSpeciality = Person.Specialty.Mathematician,
                score = 4.9
            };
            Person pers3 = new Person()
            {
                name = "Вася",
                age = 28,
                PersonSpeciality = Person.Specialty.Mechanic,
                score = 2.9
            };
            Person pers4 = new Person()
            {
                name = "Костя",
                age = 32,
                PersonSpeciality = Person.Specialty.Mechanic,
                score = 4.2
            };
            Person pers5 = new Person()
            {
                name = "Миша",
                age = 45,
                PersonSpeciality = Person.Specialty.Electrician,
                score = 4.6
            };
            Person pers6 = new Person()
            {
                name = "Марина",
                age = 25,
                PersonSpeciality = Person.Specialty.Mathematician,
                score = 4.65
            };
            Person pers7 = new Person()
            {
                name = "Петя",
                age = 34,
                PersonSpeciality = Person.Specialty.Mechanic,
                score = 4.0
            };
            Person pers8 = new Person()
            {
                name = "Паша",
                age = 27,
                PersonSpeciality = Person.Specialty.Programmer,
                score = 4.2
            };
            Person pers9 = new Person()
            {
                name = "Ксюша",
                age = 20,
                PersonSpeciality = Person.Specialty.Mathematician,
                score = 4.85
            };
            Person pers10 = new Person()
            {
                name = "Саша",
                age = 41,
                PersonSpeciality = Person.Specialty.Electrician,
                score = 4.9
            };

            Factory factory = new Factory();
            factory.Candidates.Add(pers1);
            factory.Candidates.Add(pers2);
            factory.Candidates.Add(pers3);
            factory.Candidates.Add(pers4);
            factory.Candidates.Add(pers5);
            factory.Candidates.Add(pers6);
            factory.Candidates.Add(pers7);
            factory.Candidates.Add(pers8);
            factory.Candidates.Add(pers9);
            factory.Candidates.Add(pers10);

            Inform depart1 = new Inform()
            {
                Title = "Питерский мостик",
                NumberOfVacancies = 1
            };

            Mechanic depart2 = new Mechanic()
            {
                Title = "БазисАвто",
                NumberOfVacancies = 2
            };

            Electrician depart3 = new Electrician()
            {
                Title = "Разетка",
                NumberOfVacancies = 3
            };

            factory.Departments.Add(depart1);
            factory.Departments.Add(depart2);
            factory.Departments.Add(depart3);

            foreach (Department d in factory.Departments)
            {
                d.StaffSelectoin(factory.Candidates);
            }

            Console.WriteLine($"\nСотрудники Електрического Департамента, которые были пряняты в компанию -{depart3.Title}-: ");
            foreach (Person y in depart3.Employees)
            {
                Console.WriteLine($"Имя: {y.name}, Возраст: {y.age}, Специальность: {y.PersonSpeciality}, Средний балл: {y.score}");
            }
            Console.WriteLine($"\nСотрудники Механического Департамента, которые были пряняты в компанию -{depart2.Title}-: ");
            foreach (Person y in depart2.Employees)
            {
                Console.WriteLine($"Имя: {y.name}, Возраст: {y.age}, Специальность: {y.PersonSpeciality}, Средний балл: {y.score}");
            }
            Console.WriteLine($"\nСотрудники Информотдела, которые были пряняты в компанию -{depart1.Title}-: ");
            foreach (Person y in depart1.Employees)
            {
                Console.WriteLine($"Имя: {y.name}, Возраст: {y.age}, Специальность: {y.PersonSpeciality}, Средний балл: {y.score}");
            }
            Console.WriteLine("\nНетрудоустроенные кандидаты: ");
            foreach (Person y in factory.Candidates)
            {
                Console.WriteLine($"Имя: {y.name}, Возраст: {y.age}, Специальность: {y.PersonSpeciality}, Средний балл: {y.score}");
            }

            Console.WriteLine($"\n{depart3.PrintEmployees()}");
            Console.WriteLine(depart2.PrintEmployees());
            Console.WriteLine(depart1.PrintEmployees());

            //foreach (Department d in factory.Departments)
            //{
            //    d.PrintEmployees();
            //}
        }
    }
}
