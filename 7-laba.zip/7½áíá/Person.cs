﻿namespace _6лаба
{
    public class Person
    {
        public string name { get; set; }
        public int age { get; set; }
        public enum Specialty
        {
            Electrician,
            Mechanic,
            Mathematician,
            Programmer,
            Lawyer
        }
        public Specialty PersonSpeciality;
        public double score { get; set; }
    }
}
