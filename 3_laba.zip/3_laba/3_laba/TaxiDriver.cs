﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_laba
{
    internal delegate void NotificationOfDriver(ArgsOfTaxiDriver driver);
    internal class TaxiDriver
    {
        public string Name { get; set; }
        public (double a, double b) CurrentLocation { get; set; }
        public double Ball { get; set; }
        public bool Free { get; set; }

        public Car Car;
        public event NotificationOfDriver ResponsedToOrder;

        public void GoToOrder(ArgsOfTaxiOrder order)
        {
            (double c, double d) address = order.Order.Departure.Coordinates;
            double curloc_a = CurrentLocation.a;
            double curloc_b = CurrentLocation.b;
            double road = Math.Sqrt(Math.Pow((curloc_a - address.c), 2) + Math.Pow((curloc_b - address.d), 2));
            if (Free == true && Car.ChildSeat == order.Order.ChildSeat && road <= 0.015)
            {
                if (ResponsedToOrder != null) { ResponsedToOrder.Invoke(new ArgsOfTaxiDriver(this)); }
            }
            
        }
    }
}
