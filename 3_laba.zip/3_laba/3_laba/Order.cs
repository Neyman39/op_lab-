﻿namespace _3_laba
{
    internal class Order
    {
        public Address Destinatoin;
        public Address Departure;
        public bool ChildSeat { get; set; }
        public double Distance { get; set; }
    }

}
