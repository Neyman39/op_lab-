﻿namespace _3_laba
{
    class Address
    {
        public (double, double) Coordinates { get; set; }
        public string Street { get; set; }
        public int House { get; set; }
    }

}
