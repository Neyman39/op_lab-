﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_laba
{
    class Program
    {
        static void Main(string[] args)
        {
            TaxiAggregator aggregator = new TaxiAggregator();

            Customer andry = new Customer();
            andry.Name = "Андрей Нейманов";

            Car auto1 = new Car()
            {
                Number = "А837МВ",
                Brand = "Honda Civic",
                ChildSeat = false
            };
            Car auto2 = new Car()
            {
                Number = "Б052CC",
                Brand = "Nissan Sunny",
                ChildSeat = false
            };
            Car auto3 = new Car()
            {
                Number = "О656НУ",
                Brand = "Toyota Crown",
                ChildSeat = false
            };

            TaxiDriver taxist1 = new TaxiDriver()
            {
                Name = "Влад Соколов",
                CurrentLocation = (56.002319, 92.752024),
                Ball = 4.90,
                Free = true,
                Car = auto1
            };
            TaxiDriver taxist2 = new TaxiDriver()
            {
                Name = "Александр Ермолаев",
                CurrentLocation = (56.025049, 92.8296508),
                Ball = 4.92,
                Free = false,
                Car = auto2
            };
            TaxiDriver taxist3 = new TaxiDriver()
            {
                Name = "Алексей Деревяшкин",
                CurrentLocation = (56.008639, 92.799896),
                Ball = 4.85,
                Free = true,
                Car = auto3
            };

            Address address_a = new Address()
            {
                Coordinates = (55.994637, 92.798755),
                Street = "ул. Киренского",
                House = 26
            };
            Address address_b = new Address()
            {
                Coordinates = (56.004256, 92.772263),
                Street = "Свободный пр.",
                House = 82
            };

            aggregator.AddNewTaxiDriver(taxist1);
            aggregator.AddNewTaxiDriver(taxist2);
            aggregator.AddNewTaxiDriver(taxist3);

            Console.WriteLine($"{aggregator.CreateAnOrder(andry, address_a, address_b, false)}");
        }
    }

}
