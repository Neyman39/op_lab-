﻿namespace _3_laba
{
    internal class ArgsOfTaxiDriver
    {
        public TaxiDriver TaxiDriver;
        public ArgsOfTaxiDriver(TaxiDriver driver)
        {
            this.TaxiDriver = driver;
        }
    }
}
