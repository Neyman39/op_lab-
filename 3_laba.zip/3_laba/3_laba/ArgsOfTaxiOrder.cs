﻿namespace _3_laba
{
    internal class ArgsOfTaxiOrder
    {
        public Order Order;
        public ArgsOfTaxiOrder(Order order)
        {
            this.Order = order;
        }
    }
}
