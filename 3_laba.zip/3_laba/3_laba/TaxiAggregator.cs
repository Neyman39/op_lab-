﻿using System.Collections.Generic;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3_laba
{
    class TaxiAggregator
    {
        private List<Customer> customers = new List<Customer>();
        private List<TaxiDriver> taxiDrivers = new List<TaxiDriver>();
        private List<TaxiDriver> taxiDriversTemp = new List<TaxiDriver>();

        public void AddNewTaxiDriver(TaxiDriver driver)
        {
            if (taxiDrivers.Contains(driver) == false)
            {
                taxiDrivers.Add(driver);
                driver.ResponsedToOrder += AddReadyDriverInTempList;
            }
        }
        public void RemoveTaxiDriver(TaxiDriver driver)
        {
            if (taxiDrivers.Contains(driver) == true)
            {
                taxiDrivers.Add(driver);
                driver.ResponsedToOrder -= AddReadyDriverInTempList;
            }
        }
        public TaxiDriver FindBestDriver()
        {
            double ball = 0;
            TaxiDriver Best = null;
            for (int i=0; i < taxiDriversTemp.Count; i++)
            {
                if (taxiDriversTemp[i].Ball > ball)
                {
                    ball = taxiDriversTemp[i].Ball;
                    Best = taxiDriversTemp[i];
                }
            }
            return Best;
        }
        public void AddReadyDriverInTempList(ArgsOfTaxiDriver driverArgs)
        {
            taxiDriversTemp.Add(driverArgs.TaxiDriver);
        }

        public string CreateAnOrder(Customer customer, Address depature, Address destination, bool childSeat)
        {
            if (customers.Contains(customer) == false)
            {
                customers.Add(customer);
                foreach (TaxiDriver driver in taxiDrivers)
                {
                    customer.IWantToTakeATaxi += driver.GoToOrder; // GoToOrder передает данные водителя, котрый может выполнить заказ для функции AddReadyDriver...
                }
            }
            Order order = new Order()
            {
                Departure = depature,
                Destinatoin = destination,
                ChildSeat = childSeat
            };
            customer.tempOrder = order;
            customer.TakeATaxi(); // TakeATaxi передает данные заказа для функции GoToOrder
            TaxiDriver best = FindBestDriver();
            if (best == null)
                return "Нет подходящих машин";
            return $"Водитель {best.Name} на {best.Car.Brand} с гос.номером {best.Car.Number} \n" +
                $"отправился на заказ: от {depature.Street} {depature.House} до {destination.Street} {destination.House}\n";
        }
    }
}
