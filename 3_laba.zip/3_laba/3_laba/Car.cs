﻿namespace _3_laba
{
    public class Car
    {
        public string Number { get; set; }
        public string Brand { get; set; }
        public bool ChildSeat { get; set; }
    }
}
