﻿namespace _3_laba
{
    internal delegate void NotificationOfCustomer(ArgsOfTaxiOrder order);
    class Customer
    {
        public string Name { get; set; }
        public Order tempOrder;
        public event NotificationOfCustomer IWantToTakeATaxi;

        public void TakeATaxi()
        {
            if (IWantToTakeATaxi != null) { IWantToTakeATaxi.Invoke(new ArgsOfTaxiOrder(tempOrder)); }
        }
    }
}
