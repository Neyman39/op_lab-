﻿namespace _8лаба
{
    public class GentleSmartphone
    {
        public TactileSensor Sensor;
        public GentleSmartphone(byte sens)
        {
            Sensor = new TactileSensor(sens);
        }
        public int SerialNumber { get; set; }
    }
}
