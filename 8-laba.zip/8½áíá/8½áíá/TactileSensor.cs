﻿namespace _8лаба
{
    public class TactileSensor
    {
        public byte Sensivity { get; set; }

        public TactileSensor(byte sens)
        {
            Sensivity = sens;
        }
    }


}
