﻿using System.Collections.Generic;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8лаба
{
    public class Factory
    {
        public Factory()
        {
            List<GentleSmartphone> Smartphones;
        }
        public List<Customer> Customers;
        public List<GentleSmartphone> Smartphones;

        
        public void SaleSmartphone1()
        {
            Random rnd = new Random();
            int i = rnd.Next(1000, 2000);
            double sensivit;
            double sensivit1;

            foreach (Customer x in Customers)
            {
                foreach (GentleSmartphone y in Smartphones)
                {
                    if (y.Sensor.Sensivity/x.GentleRate < 1.5 && x.GentleRate/y.Sensor.Sensivity < 2 && x.Smartphone == null)
                    {
                        x.Smartphone = y;
                        Smartphones.Remove(y);
                        break;
                    }
                    else if (y.Sensor.Sensivity/x.GentleRate > 1.5 && x.GentleRate/y.Sensor.Sensivity < 2.0 && x.Smartphone == null)
                    {
                        Transformator form1 = new Transformator()
                        {
                            SerialNumber = i,
                            FormType = Transformator.TrasformatorType.Divider
                        };
                        
                        x.TransformModule = form1;
                        sensivit = y.Sensor.Sensivity/2.0;
                        if ((sensivit/x.GentleRate) < 1.5 && (x.GentleRate/sensivit) < 2)
                        {
                            x.Smartphone = y;
                            Smartphones.Remove(y);
                            break;
                        }
                    }
                    else if (((y.Sensor.Sensivity/x.GentleRate) < 1.5) && ((x.GentleRate/y.Sensor.Sensivity) > 2.0) && x.Smartphone == null)
                    {
                        Transformator form2 = new Transformator()
                        {
                            SerialNumber = i,
                            FormType = Transformator.TrasformatorType.Multiplier
                        };
                        
                        x.TransformModule = form2;
                        sensivit1 = y.Sensor.Sensivity*2.0;
                        if ((sensivit1/x.GentleRate) < 1.5 && (x.GentleRate/sensivit1) < 2)
                        {
                            x.Smartphone = y;
                            Smartphones.Remove(y);
                            break;
                        }
                    }
                }
            }        
            Smartphones.Clear();
        }
        public void SaleSmartphone2()
        {
            Random rnd = new Random();
            int i = rnd.Next(1000, 2000);
            foreach (Customer x in Customers)
            {
                foreach (GentleSmartphone y in Smartphones)
                {
                    if (y.Sensor.Sensivity/x.GentleRate < 1.5 && x.GentleRate/y.Sensor.Sensivity < 2 && x.Smartphone == null)
                    {
                        x.Smartphone = y;
                        Smartphones.Remove(y);
                        break;
                    }
                }
                if (x.Smartphone == null)
                {
                    foreach(GentleSmartphone y in Smartphones)
                    {
                        if ((y.Sensor.Sensivity/2)/x.GentleRate < 1.5 && x.GentleRate/(y.Sensor.Sensivity/2) < 2 && x.Smartphone == null)
                        {
                            Transformator form1 = new Transformator()
                            {
                                SerialNumber = i,
                                FormType = Transformator.TrasformatorType.Divider
                            };
                            x.TransformModule = form1;
                            x.Smartphone = y;
                            Smartphones.Remove(y);
                            break;
                        }
                        if ((y.Sensor.Sensivity*2)/x.GentleRate < 1.5 && x.GentleRate/(y.Sensor.Sensivity*2) < 2 && x.Smartphone == null)
                        {
                            Transformator form2 = new Transformator()
                            {
                                SerialNumber = i,
                                FormType = Transformator.TrasformatorType.Multiplier
                            };
                            x.TransformModule = form2;
                            x.Smartphone = y;
                            Smartphones.Remove(y);
                            break;
                        }

                    }
                }  
            }   
            Smartphones.Clear();
        }
    }
}

