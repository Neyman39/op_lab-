﻿namespace _8лаба
{
    public class Customer
    {
        public string FullName { get; set; }
        public byte GentleRate { get; set; }
        public GentleSmartphone Smartphone;
        public Transformator TransformModule;
        public Customer(string FullName, byte GentleRate)
        {
            this.FullName = FullName;
            this.GentleRate = GentleRate;
        }
    }
}
