﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8лаба
{
    class Program
    {
        static void Main(string[] args)
        {
            
            GentleSmartphone phone1 = new GentleSmartphone(68) {SerialNumber = 15901};
            GentleSmartphone phone2 = new GentleSmartphone(35) {SerialNumber = 15902};
            GentleSmartphone phone3 = new GentleSmartphone(22) {SerialNumber = 15903};
            GentleSmartphone phone4 = new GentleSmartphone(15) {SerialNumber = 15904};
            GentleSmartphone phone5 = new GentleSmartphone(110) {SerialNumber = 15905};
            GentleSmartphone phone6 = new GentleSmartphone(53) {SerialNumber = 15906};
            Customer pers1 = new Customer("Alex Bebra", 80);
            Customer pers2 = new Customer("James Statehame", 59);
            Customer pers3 = new Customer("Lomalmo Samsonov", 225);
            Customer pers4 = new Customer("Harry Bubukin", 5);
            Customer pers5 = new Customer("Liza Dunova", 97);
            Customer pers6 = new Customer("Loid Computern", 41);

            Factory factory = new Factory();
            factory.Customers = new System.Collections.Generic.List<Customer>();
            factory.Smartphones = new System.Collections.Generic.List<GentleSmartphone>();
            factory.Customers.Add(pers1);
            factory.Customers.Add(pers2);
            factory.Customers.Add(pers3);
            factory.Customers.Add(pers4);
            factory.Customers.Add(pers5);
            //factory.Customers.Add(pers6);
            factory.Smartphones.Add(phone1);
            factory.Smartphones.Add(phone2);
            factory.Smartphones.Add(phone3);
            factory.Smartphones.Add(phone4);
            factory.Smartphones.Add(phone5);
            factory.Smartphones.Add(phone6);

            Console.WriteLine("== Телефоны ==");
            foreach (GentleSmartphone x in factory.Smartphones)
            {
                Console.WriteLine($"Чувствительность телефона: {x.Sensor.Sensivity}, серийный номер-{x.SerialNumber}");
            }
            Console.WriteLine("== Клиенты == ");
            foreach (Customer x in factory.Customers)
            {
                Console.WriteLine($"ФИ: {x.FullName}, уровень нежности: {x.GentleRate}");
            }

            factory.SaleSmartphone2();

            Console.WriteLine("\n== Телефоны == ");
            foreach (GentleSmartphone i in factory.Smartphones)
            {
                Console.WriteLine($"Чувствительность телефона: {i.Sensor.Sensivity}, серийный номер - {i.SerialNumber}");
            }
            if (factory.Smartphones.Count == 0)
                Console.WriteLine("--");
            Console.WriteLine("== Клиенты == ");          
            foreach (Customer i in factory.Customers)
            {
                if (i.Smartphone != null)
                {
                    if (i.TransformModule == null)
                        Console.WriteLine($"ФИ: {i.FullName}, уровень нежности: {i.GentleRate}, с№-{i.Smartphone.SerialNumber}");
                    else
                        Console.WriteLine($"ФИ: {i.FullName}, уровень нежности: {i.GentleRate}, с№-{i.Smartphone.SerialNumber}, трансформатор: {i.TransformModule.FormType}");
                }
            }
            Console.WriteLine("Остались без телефона :(");
            foreach (Customer i in factory.Customers)
            {
                if (i.Smartphone == null)
                {
                    Console.WriteLine($"ФИ: {i.FullName}, уровень нежности: {i.GentleRate}");
                }
            }
            
        }
    }
}

