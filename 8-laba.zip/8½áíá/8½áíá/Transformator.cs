﻿namespace _8лаба
{
    public class Transformator
    {
        public int SerialNumber { get; set; }
        public enum TrasformatorType
        {
            Multiplier,
            Divider
        }
        public TrasformatorType FormType;
    }
}

